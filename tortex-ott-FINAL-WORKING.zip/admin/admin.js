
function adminSignIn(){
  var u=document.getElementById("adminUser"),p=document.getElementById("adminPass"),g=document.getElementById("adminLogin");
  if(u && p && u.value.trim()==="Rohan" && p.value==="Rohan@5566"){
    if(g){g.style.display="none";g.classList.add("hidden");}
    try{sessionStorage.setItem("tortexAdmin","1")}catch(e){}
  }else{
    alert("Wrong username or password");
  }
}

document.addEventListener("DOMContentLoaded",function(){
  var b=document.getElementById("adminSignInBtn");
  if(b)b.addEventListener("click",adminSignIn);
  [document.getElementById("adminUser"),document.getElementById("adminPass")].forEach(function(x){
    if(x)x.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();adminSignIn();}});
  });
  try{
    if(sessionStorage.getItem("tortexAdmin")==="1"){
      var g=document.getElementById("adminLogin");if(g){g.style.display="none";g.classList.add("hidden");}
    }
  }catch(e){}
});
