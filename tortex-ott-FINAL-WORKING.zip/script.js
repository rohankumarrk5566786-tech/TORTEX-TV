
/* Tortex working browser authentication */
(function(){
  function $(id){return document.getElementById(id)}
  function users(){try{return JSON.parse(localStorage.getItem("tortexUsers")||"[]")}catch(e){return[]}}
  function saveUsers(v){localStorage.setItem("tortexUsers",JSON.stringify(v))}
  var panel=$("loginPanel"), profile=$("profileBtn"), close=$("closeLogin"), msg=$("authMessage");
  profile&&profile.addEventListener("click",function(){panel&&panel.classList.add("open")});
  close&&close.addEventListener("click",function(){panel&&panel.classList.remove("open")});
  panel&&panel.addEventListener("click",function(e){if(e.target===panel)panel.classList.remove("open")});
  $("loginTab")&&$("loginTab").addEventListener("click",function(){
    $("loginTab").classList.add("active");$("signupTab").classList.remove("active");
    $("loginForm").style.display="block";$("signupForm").style.display="none";
  });
  $("signupTab")&&$("signupTab").addEventListener("click",function(){
    $("signupTab").classList.add("active");$("loginTab").classList.remove("active");
    $("loginForm").style.display="none";$("signupForm").style.display="block";
  });
  $("loginBtn")&&$("loginBtn").addEventListener("click",function(){
    var e=$("email").value.trim().toLowerCase(),p=$("password").value;
    var u=users().find(function(x){return x.email===e&&x.password===p});
    if(!u){if(msg)msg.textContent="Wrong email/password. Please Sign Up first.";return}
    localStorage.setItem("tortexCurrentUser",JSON.stringify({name:u.name,email:u.email}));
    panel.classList.remove("open");
    if(typeof showToast==="function")showToast("Welcome, "+u.name+"!");
    if(profile)profile.textContent=u.name.slice(0,2).toUpperCase();
  });
  $("signupBtn")&&$("signupBtn").addEventListener("click",function(){
    var n=$("signupName").value.trim(),e=$("signupEmail").value.trim().toLowerCase(),p=$("signupPassword").value;
    if(!n||!e||p.length<6){if(msg)msg.textContent="Enter name, email and a 6+ character password.";return}
    var u=users();
    if(u.some(function(x){return x.email===e})){if(msg)msg.textContent="This email is already registered.";return}
    u.push({name:n,email:e,password:p});saveUsers(u);
    localStorage.setItem("tortexCurrentUser",JSON.stringify({name:n,email:e}));
    panel.classList.remove("open");
    if(typeof showToast==="function")showToast("Account created successfully!");
    if(profile)profile.textContent=n.slice(0,2).toUpperCase();
  });
})();
