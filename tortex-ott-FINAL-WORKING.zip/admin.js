const modal=document.getElementById("modal"),title=document.getElementById("modalTitle"),toast=document.getElementById("toast");

function openModal(t){if(title&&modal){title.textContent=t;modal.classList.add("open")}}
function closeModal(){if(modal)modal.classList.remove("open")}
function saveModal(){closeModal();showToast("Saved successfully (demo mode)")}
function showToast(t){
  if(!toast)return;
  toast.textContent=t;toast.classList.add("show");
  clearTimeout(window.tt);window.tt=setTimeout(()=>toast.classList.remove("show"),2200)
}
function removeRow(btn){
  if(confirm("Delete this content?")){btn.closest("tr").remove();showToast("Content deleted (demo mode)")}
}
if(modal) modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");showToast(`${b.textContent} filter selected`)
});

/* Tortex Admin Login */
function adminSignIn(){
  const user=document.getElementById("adminUser");
  const pass=document.getElementById("adminPass");
  const gate=document.getElementById("adminLogin");
  const msg=document.getElementById("loginMessage");
  if(!user||!pass||!gate)return;

  const u=user.value.trim();
  const p=pass.value;

  if(u==="Rohan" && p==="Rohan@5566"){
    gate.style.display="none";
    gate.classList.add("hidden");
    if(msg){msg.textContent="Login successful";msg.className="login-message success"}
    try{sessionStorage.setItem("tortexAdmin","1")}catch(e){}
  }else{
    if(msg){msg.textContent="Wrong username or password";msg.className="login-message"}
  }
}

document.addEventListener("DOMContentLoaded",()=>{
  const btn=document.getElementById("adminSignInBtn");
  const user=document.getElementById("adminUser");
  const pass=document.getElementById("adminPass");

  btn?.addEventListener("click",adminSignIn);
  [user,pass].forEach(el=>el?.addEventListener("keydown",e=>{
    if(e.key==="Enter"){e.preventDefault();adminSignIn()}
  }));

  /* Keep session only if browser supports it. */
  try{
    if(sessionStorage.getItem("tortexAdmin")==="1"){
      const gate=document.getElementById("adminLogin");
      if(gate){gate.style.display="none";gate.classList.add("hidden")}
    }
  }catch(e){}
});
